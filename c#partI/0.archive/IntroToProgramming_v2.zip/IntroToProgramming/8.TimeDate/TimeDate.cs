﻿using System;

class NumbersOnScreen
{
    static void Main()
    {
        Console.WriteLine("Дата и час " + DateTime.Now);
    }
}