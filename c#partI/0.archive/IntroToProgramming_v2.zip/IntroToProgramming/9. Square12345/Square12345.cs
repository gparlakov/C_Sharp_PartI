﻿using System;

class NumbersOnScreen
{
    static void Main() 
    {
        Console.WriteLine("Квадратът на 12345 е " + Math.Pow(12345,2));       
    }
}