﻿using System;


class NameSirN
{
    static void Main(string[] args)
    {
        Console.WriteLine("Името ми е Георги Парлъков.");
    }
}

