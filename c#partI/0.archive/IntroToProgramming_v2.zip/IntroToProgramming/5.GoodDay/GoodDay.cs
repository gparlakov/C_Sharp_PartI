﻿using System;

class HelloC
{
    static void Main()
    {
        Console.WriteLine("Добър Ден!");
    }
}
