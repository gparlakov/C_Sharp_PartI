﻿using System;
/* 52130,-115,4825932,97,-10000*/



class PrimitiveTypes
{
    static void Main()
    {
        ushort firstValue = 52130;
        sbyte secondValue = -115;
        int thirdValue = 4825932;
        byte fourthValue = 97;
        int fifthValue = -10000;
        Console.WriteLine("{0};{1};{2};{3};{4}",firstValue,secondValue,thirdValue,fourthValue,fifthValue);
    }
}

