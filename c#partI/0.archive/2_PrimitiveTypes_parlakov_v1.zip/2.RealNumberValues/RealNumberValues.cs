﻿using System;
/*34.567839023, 12.345,8923.1234857, 3456.091*/


class RealNumberValues
{
    static void Main()
    {
        double firstVar = 34.567839023;
        float secondVar = 12.345F;
        double thirdVar = 8923.12345857;
        float fourthVar = 3456.091F;
        Console.WriteLine("The variables declared have literals: \n{0}; {1}; {2}; {3}", firstVar, secondVar, thirdVar, fourthVar);

    }
}

