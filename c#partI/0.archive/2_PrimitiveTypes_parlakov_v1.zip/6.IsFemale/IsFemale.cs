﻿using System;


  class IsFemale
    {
        static void Main()
        {
            bool isFemale = false;
            Console.WriteLine("Polat mi jenski li e? {0}.",isFemale);
        }
    }

